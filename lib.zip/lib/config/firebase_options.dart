// Este archivo fue generado automáticamente por la herramienta FlutterFire CLI.
// No se recomienda modificarlo manualmente, ya que puede ser sobrescrito si se vuelve a generar.
// ignore_for_file: type=lint
// Esta línea desactiva advertencias específicas del analizador de código relacionadas con el estilo.

// Importa la clase FirebaseOptions, que contiene las configuraciones necesarias para inicializar Firebase.
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;

// Importa utilidades de Flutter para determinar la plataforma actual y si la aplicación se ejecuta en la web.
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

/// Clase que contiene las configuraciones predeterminadas de Firebase para las plataformas soportadas.
///
/// Ejemplo de uso:
/// ```dart
/// import 'firebase_options.dart';
/// // ...
/// await Firebase.initializeApp(
///   options: DefaultFirebaseOptions.currentPlatform,
/// );
/// ```
/// Esta clase facilita la inicialización de Firebase seleccionando automáticamente
/// las configuraciones correctas según la plataforma en la que se ejecuta la aplicación.
class DefaultFirebaseOptions {
  // Método que devuelve las configuraciones de Firebase según la plataforma actual.
  static FirebaseOptions get currentPlatform {
    // Si la aplicación se ejecuta en la web, devuelve las configuraciones para la web.
    if (kIsWeb) {
      return web;
    }
    // Si no es web, selecciona la configuración según la plataforma detectada.
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        // Configuración para Android.
        return android;
      case TargetPlatform.iOS:
        // Configuración para iOS.
        return ios;
      case TargetPlatform.macOS:
        // Si la plataforma es macOS, lanza un error indicando que no está configurada.
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for macos - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      case TargetPlatform.windows:
        // Si la plataforma es Windows, lanza un error indicando que no está configurada.
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for windows - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      case TargetPlatform.linux:
        // Si la plataforma es Linux, lanza un error indicando que no está configurada.
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for linux - '
          'you can reconfigure this by running the FlutterFire CLI again.',
        );
      default:
        // Si la plataforma no es reconocida, lanza un error genérico.
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  // Configuración específica para aplicaciones web.
  static const FirebaseOptions web = FirebaseOptions(
    apiKey:
        'AIzaSyBFjQ8xLPkOR7EqN-sbu8c2UJslyYpaXD0', // Clave de API para la web.
    appId:
        '1:514459263466:web:f16b0ca33cf3bd8ff85293', // ID de la aplicación Firebase para la web.
    messagingSenderId:
        '514459263466', // ID del remitente de mensajes de Firebase Cloud Messaging.
    projectId: 'gabimaps-ad5d6', // ID del proyecto de Firebase.
    authDomain:
        'gabimaps-ad5d6.firebaseapp.com', // Dominio de autenticación para la web.
    storageBucket:
        'gabimaps-ad5d6.firebasestorage.app', // URL del bucket de almacenamiento.
    measurementId: 'G-Z35BGWSKXQ', // ID de medición para Google Analytics.
  );

  // Configuración específica para aplicaciones Android.
  static const FirebaseOptions android = FirebaseOptions(
    apiKey:
        'AIzaSyCTyVJtRKoVp2RUIBKDSACwqev27hKzL9Y', // Clave de API para Android.
    appId:
        '1:514459263466:android:fa495253312abdc0f85293', // ID de la aplicación Firebase para Android.
    messagingSenderId:
        '514459263466', // ID del remitente de mensajes de Firebase Cloud Messaging.
    projectId: 'gabimaps-ad5d6', // ID del proyecto de Firebase.
    storageBucket:
        'gabimaps-ad5d6.firebasestorage.app', // URL del bucket de almacenamiento.
  );

  // Configuración específica para aplicaciones iOS.
  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyAEqbUaUfjb6m5PhHqgq_ICAWkY-MNN4bM', // Clave de API para iOS.
    appId:
        '1:514459263466:ios:b317a28a2dc88d9cf85293', // ID de la aplicación Firebase para iOS.
    messagingSenderId:
        '514459263466', // ID del remitente de mensajes de Firebase Cloud Messaging.
    projectId: 'gabimaps-ad5d6', // ID del proyecto de Firebase.
    storageBucket:
        'gabimaps-ad5d6.firebasestorage.app', // URL del bucket de almacenamiento.
    iosBundleId: 'com.example.gabimaps', // ID del paquete de la aplicación iOS.
  );
}
